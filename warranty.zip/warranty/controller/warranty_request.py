import datetime

from odoo.http import Controller, request, route


class WarrantyRequest(Controller):
    @route(route='/warranty', auth='public', website=True)
    def warranty(self):
        print('warranty', request.env.uid)
        invoice_id = request.env['account.move'].search(
            [('move_type', '=', 'out_invoice'), ('state', 'in', ['posted'])])
        print(invoice_id.ids)

        product_ids = request.env['product.product'].search([('has_warranty', '=', 'True')])
        print(product_ids)
        date = datetime.date.today()

        lot = request.env['stock.lot'].search([])

        return request.render('warranty.warranty_request_template',
                              {'invoice_id': invoice_id,
                               'product_ids': product_ids,
                               'date': date,
                               'lot': lot,
                               })

    @route(route='/getdata', type='json', auth='user', methods=['POST'], website=True, csrf=False)
    def get_data(self, **kw):

        invoice_id = int(kw.get('invoice'))
        print(invoice_id)
        if invoice_id:

            invoice = request.env['account.move'].browse(invoice_id)
            print(invoice)
            products = invoice.invoice_line_ids.mapped('product_id')

            product_names = [{'id': rec.id, 'name': rec.name} for rec in products if rec.has_warranty]
            print(product_names)
            purchase_date = invoice.invoice_date
            customer = {'id': invoice.partner_id.id, 'name': invoice.partner_id.name}
            print(customer)

            return {
                'products': product_names,
                'purchase_date': purchase_date,
                'customer': customer,
            }

    @route(route='/getproductdata', type='json', auth='user', methods=['POST'], website=True, csrf=False)
    def get_product_data(self, **kw):
        product_id = int(kw.get('product'))
        invoice_id = int(kw.get('invoice'))
        invoice = request.env['account.move'].browse(invoice_id)
        purchase_date = invoice.invoice_date
        if product_id:
            product = request.env['product.product'].browse(product_id)
            warranty_periods = product.warranty_periods
            warranty_expiry = purchase_date + datetime.timedelta(days=warranty_periods)
            print(warranty_expiry)

            return {
                'warranty_expiry': warranty_expiry
            }

    @route(route='/create/warranty', auth='public', website=True, csrf=False)
    def create_warranty(self, **kw):
        print("create warranty ", kw)
        product_id = kw.get('product')
        if product_id:
            warranty = request.env['warranty'].create({
                'date': kw.get('date'),
                'invoice_id': kw.get('invoice'),
                'product_id': product_id,
                'customer_id': kw.get('customer_id'),
                'purchase_date': kw.get('purchase_date'),
                'warranty_expire_date': kw.get('expiry_date'),

            })
            print(warranty)
        return request.render('warranty.website_warranty_success_template')


class WarrantyRequestList(Controller):
    @route(route='/requests', auth='public', website=True)
    def warranty_list(self):
        user_id = request.env.user.id
        print(user_id)
        warranty_requests = request.env['warranty'].search([('create_uid', '=', user_id)])
        print(warranty_requests)

        return request.render('warranty.warranty_request_list_template',
                              {
                                  'warranty_req': warranty_requests
                              })

