odoo.define('warranty.website_warranty_list_menu', function (require) {
'use strict';

})














//    var core = require('web.core');
//
//    var _t = core._t;
//
//    $(document).ready(function () {
//        var $warrantyTable = $('.warranty-request-table tbody');
//
//        // Make an AJAX request to retrieve user-specific warranty requests
//        ajax.jsonRpc('/my_warranty_requests', 'call', {}).then(function (data) {
//            if (data) {
//                $warrantyTable.empty(); // Clear any existing rows
//
//                $.each(data, function (index, request) {
//                    var row = '<tr>' +
//                        '<td>' + request.id + '</td>' +
//                        '<td>' + request.name + '</td>' +
//                        '<td>' + request.product_name + '</td>' +  // Replace with the actual field name
//                        '</tr>';
//                    $warrantyTable.append(row);
//                });
//            } else {
//                $warrantyTable.html('<tr><td colspan="3">' + _t('No warranty requests found.') + '</td></tr>');
//            }
//        });
//    });
//});
