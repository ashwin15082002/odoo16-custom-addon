odoo.define('warranty.warranty_request_template', function (require) {
'use strict';

var publicWidget = require('web.public.widget');
var ajax = require('web.ajax');


console.log("hello");
publicWidget.registry.warrantyRequest = publicWidget.Widget.extend({
    selector: '#warranty_form',
    events: {
        'change #invoice_id': '_onInvoiceChange',
        'change #product_ids': '_onProductChange',
    },

    _onInvoiceChange: function () {
        var invoice = $('#invoice_id').val();
        console.log(invoice, 'invoice');

        ajax.jsonRpc('/getdata', 'call', {
                       'invoice' : invoice,
                      })
        .then(function (data) {
            console.log(data)
            $("#expiry_date").val("");
            var productDropdown = $("#product_ids");
                productDropdown.empty();
            $('#product_ids').prepend($('<option> Select Product </option>'));
            $.each(data.products, function (index, product) {
                    productDropdown.append($('<option>', {
                        value: product.id,
                        text: product.name,

                    }));
                });

            $("#customer").val(data.customer.name);
            $("#customer_id").val(data.customer.id);
            $("#purchase_date").val(data.purchase_date);
            console.log($("#customer").text())
        });
    },

    _onProductChange: function() {
        var product = $('#product_ids').val();
        var invoice = $('#invoice_id').val();
        console.log(product);

        ajax.jsonRpc('/getproductdata', 'call', {
                       'product' : product,
                       'invoice': invoice,
                      })
        .then(function (data) {
            console.log(data)
            $("#expiry_date").val(data.warranty_expiry);

        });

    },
    })
})
