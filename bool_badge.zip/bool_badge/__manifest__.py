{
    'name': "Bool Badge",
    'version': '16.0.1.0.0',
    'depends': ['web'],
    'assets':{
        'web.assets_backend':[
            '/bool_badge/static/src/xml/bool_badge.xml',
            '/bool_badge/static/src/js/bool_badge.js',
        ]
    }

}
