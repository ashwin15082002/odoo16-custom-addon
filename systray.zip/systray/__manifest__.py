{
    'name': "nnn",
    'version': '16.0.1.0.0',
    'depends': ['web'],
    'assets':{
        'web.assets_backend':[
            '/systray/static/src/xml/increment.xml',
            '/systray/static/src/js/increment.js',
        ]
    }

}
