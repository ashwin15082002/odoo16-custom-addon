odoo.define('idle_timer.custom_time', function (require) {

    var publicWidget = require('web.public.widget');
    var rpc = require('web.rpc');

    publicWidget.registry.custom_time = publicWidget.Widget.extend({
    selector: '.o_survey_form',

    start: function() {
        this._rpc({
           model: 'ir.config_parameter',
           method: 'get_param',
           args:['idle_timer.idle_timer'],
        }).then(function(result){
           console.log(result)
           time = result;
           currentSec = time;
        })
        let begin_in = 5;
        setInterval(startIdleTimer,1000);

        window.onmousemove = ResetTimer;
        window.onclick = ResetTimer;
        window.onkeydown = ResetTimer;

        function ResetTimer(){
            currentSec = time;
            begin_in = 5
            $('#timer').text('');
        }

        function startIdleTimer(){
            begin_in--;
            if (begin_in <=0 && currentSec > 0){
                $('#timer').text(currentSec);
                currentSec--;

                if (currentSec == 0){
                    $('.btn-primary').click();
                    $('#timer').text('');
                }
            }

        }

    }
    })
});



/*

constructor() {
            super();

            this.timer = useRef('timer');
            this.currentSec = 0;
            this.beginIn = 5;
            console.log(this.currentSec)

            useInterval(() => this.startIdleTimer(), 1000);

            window.addEventListener('mousemove', this.resetTimer.bind(this));
            window.addEventListener('click', this.resetTimer.bind(this));
            window.addEventListener('keydown', this.resetTimer.bind(this));
        }

        resetTimer() {
            this.currentSec = this.time;
            this.beginIn = 5;
            this.timer.el.textContent = '';
        }

        startIdleTimer() {
            this.beginIn--;

            if (this.beginIn <= 0 && this.currentSec > 0) {
                this.timer.el.textContent = this.currentSec;
                this.currentSec--;
                console.log(this.currentSec)

                if (this.currentSec === 0) {
                    this.env.services.rpc({
                        model: 'ir.config_parameter',
                        method: 'get_param',
                        args: ['idle_timer.idle_timer'],
                    }).then(result => {
                        this.time = result;
                        this.resetTimer();
                        this.env.qweb.forceUpdate();
                        this.el.querySelector('.btn-primary').click();
                    });
                }
            }
        }
    }

    IdleTimer.template = 'idle_timer.idle_timer';
    IdleTimer.env = owl.Environment;